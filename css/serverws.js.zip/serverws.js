"use strict";

//parse.com module
var kaiseki=require('kaiseki');
// Optional. You will see this name in eg. 'ps' or 'top' command
process.title = 'node-chat';

// Port where we'll run the websocket server
var webSocketsServerPort = 1337;

// websocket and http servers
var webSocketServer = require('websocket').server;
var http = require('http');
/**
 * Global variables
 */
// latest 100 messages
var history = [ ];
// list of currently connected clients (users)
var clients = [ ];

/**
 * Helper function for escaping input strings
 */
function htmlEntities(str) {
    return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;')
                      .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

// Array with some colors
var colors = [ 'red', 'green', 'blue', 'magenta', 'purple', 'plum', 'orange' ]
// ... in random order
colors.sort(function(a,b) { return Math.random() > 0.5; } );

/**
 * HTTP server
 */
var server = http.createServer(function(request, response) {
    // Not important for us. We're writing WebSocket server, not HTTP server
});
server.listen(webSocketsServerPort, function() {
    console.log((new Date()) + " Server is listening on port " + webSocketsServerPort);
});

/**
 * WebSocket server
 */
var wsServer = new webSocketServer({
    // WebSocket server is tied to a HTTP server. WebSocket request is just
    // an enhanced HTTP request. For more info http://tools.ietf.org/html/rfc6455#page-6
    httpServer: server
});


//render html
var fs=require('fs');
fs.readFile('./index.html', function (err, html) {
    http.createServer (function(request, response) {
        response.writeHeader(200, {"Content-Type":"text/html"});
        response.write(html);
        response.end();
    }).listen(8000);
}); 

var APP_ID="wI8jemoyzMyVBE0exSIfoRjljded4dD4rG4jXTo0";
var REST_API_KEY="DloOEut1xtWKYH4sLebVl7ngsUeSNq5iu4AMwRRa";

var Kaiseki=require ('kaiseki');
var kaiseki=new Kaiseki(APP_ID, REST_API_KEY);

var className='TestObject';
var objectId='b0zKvCJ2WF';

kaiseki.updateObject(className, objectId, 
  {VideoURL: 'test'},
  function(err, res, body, success) {
    console.log (success);
    console.log ('object updated at=', body.updatedAt);
});

//kaiseki.getObjects(className, function(err, res, body, success) {
//  console.log ("success", success);
//  console.log ('body', body);
//});
/*
    var TestObject = moduleA.Parse.Object.extend("TestObject");
    var query = new moduleA.Parse.Query(TestObject);
    // Finds objects that have the score set
    query.exists("VideoURL");
    query.find({
      success: function(results) {
        console.log("Successfully retrieved " + results.length + " scores.");
      },
      error: function(error) {
        console.log("Error: " + error.code + " " + error.message);
      }
    });
*/

// This callback function is called every time someone
// tries to connect to the WebSocket server
wsServer.on('request', function(request) {
    console.log((new Date()) + ' Connection from origin ' + request.origin + '.');

    // accept connection - you should check 'request.origin' to make sure that
    // client is connecting from your website
    // (http://en.wikipedia.org/wiki/Same_origin_policy)
    var connection = request.accept(null, request.origin); 
    // we need to know client index to remove them on 'close' event
    var index = clients.push(connection) - 1;
    var userName = false;
    var userColor = false;

    console.log((new Date()) + ' Connection accepted.');

    // send back chat history
    if (history.length > 0) {
        connection.sendUTF(JSON.stringify( { type: 'history', data: history} ));
    }

    // user sent some message
    connection.on('message', function(message) {
         console.log ("message!!");
        if (message.type === 'utf8') { // accept only text
            if (userName === false) { // first message sent by user is their name
                // remember user name
                userName = htmlEntities(message.utf8Data);
                // get random color and send it back to the user
                userColor = colors.shift();
                connection.sendUTF(JSON.stringify({ type:'color', data: userColor }));
                console.log((new Date()) + ' User is known as: ' + userName
                            + ' with ' + userColor + ' color.');

                

            } else { // log and broadcast the message
                console.log((new Date()) + ' Received Message from '
                            + userName + ': ' + message.utf8Data);
                
                // we want to keep history of all sent messages
                var obj = {
                    time: (new Date()).getTime(),
                    text: htmlEntities(message.utf8Data),
                    author: userName,
                    color: userColor
                };
                history.push(obj);
                history = history.slice(-100);

                // broadcast message to all connected clients
                var json = JSON.stringify({ type:'message', data: obj });
                for (var i=0; i < clients.length; i++) {
                    clients[i].sendUTF(json);
                }
            }
        }
    });

    // user disconnected
    connection.on('close', function(connection) {
        if (userName !== false && userColor !== false) {
            console.log((new Date()) + " Peer "
                + connection.remoteAddress + " disconnected.");
            // remove user from the list of connected clients
            clients.splice(index, 1);
            // push back user's color to be reused by another user
            colors.push(userColor);
        }
    });

});
